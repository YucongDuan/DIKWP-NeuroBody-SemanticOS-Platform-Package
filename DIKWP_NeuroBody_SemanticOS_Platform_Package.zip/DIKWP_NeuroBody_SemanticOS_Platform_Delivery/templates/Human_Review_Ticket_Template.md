# Human Review Ticket

- Ticket ID:
- Packet ID:
- Requested Action:
- Action Grade:
- User Consent State:
- Signal Quality:
- Intent Confidence:
- Residuals:
- Required Approvers:
- Decision: approve / reject / request more info / rollback
- Reason:
- Time:
