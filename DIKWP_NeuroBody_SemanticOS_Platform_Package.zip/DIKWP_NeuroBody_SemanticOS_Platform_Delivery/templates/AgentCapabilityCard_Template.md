# Adapter / Agent Capability Card

- Adapter ID:
- Type: sensor / agent / device / model / audit / twin
- Modalities:
- Read Scope:
- Write Scope:
- Max Action Grade: A0 / A1 / A2 / A3 / A4
- Requires Consent: yes/no
- Requires Human Approval: yes/no
- Safety Interlocks:
- Data Retention:
- Incident Contact:
- Notes:
