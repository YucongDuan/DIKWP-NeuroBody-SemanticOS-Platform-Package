# Safety / Governance Incident Report

- Incident ID:
- Time:
- Severity:
- Related Session:
- Related Packet:
- Trigger:
- Description:
- Immediate Action:
- Rollback:
- Root Cause:
- Preventive Control:
- Owner:
- Status:
