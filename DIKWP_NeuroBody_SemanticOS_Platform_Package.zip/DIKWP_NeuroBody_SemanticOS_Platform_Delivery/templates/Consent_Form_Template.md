# NeuroBody SemanticOS Consent Form Template

Purpose of session:

Data modalities to be collected:

What the system may infer:

What the system will not infer:

Allowed uses:

Forbidden uses:

Data retention period:

Withdrawal method:

Contact for questions:

Participant confirmation:

Signature / date:
