# Source Ledger

- **FDA BCI guidance** — Implanted BCI devices for paralysis/amputation; non-clinical testing and clinical considerations: https://www.fda.gov/regulatory-information/search-fda-guidance-documents/implanted-brain-computer-interface-bci-devices-patients-paralysis-or-amputation-non-clinical-testing
- **UNESCO Neurotechnology Ethics** — Mental privacy, neural data, dignity and free thought safeguards: https://www.unesco.org/en/ethics-neurotech
- **OECD Neurotechnology Recommendation** — Responsible innovation in neurotechnology; stewardship, safety, privacy, oversight and societal deliberation: https://legalinstruments.oecd.org/en/instruments/OECD-LEGAL-0457/
- **IEEE Brain Standards Roadmap** — Standards roadmap for neurotechnologies and brain-machine interfaces: https://brain.ieee.org/resources/standards/
- **OpenBCI** — Open-source biosensing and BCI tools; non-invasive prototyping ecosystem: https://openbci.com/
- **Model Context Protocol** — Open standard for connecting AI applications to external systems, tools and workflows: https://modelcontextprotocol.io/docs/getting-started/intro
- **YucongDuan / DIKWP-BusTrustOps-V4** — Evidence Ledger, DIKWP SemanticClosure, Action Ticket, role governance, multi-agent coordination, white-box evaluation: https://github.com/YucongDuan/DIKWP-BusTrustOps-V4-Demo-System
- **YucongDuan / DIKWP-SemanticJustice-Studio-V2** — Offline-first evidence-linked semantic space, custody ledger, observer boundaries, human-review boundaries: https://github.com/YucongDuan/DIKWP-SemanticJustice-Studio-V2