import json, time, pathlib
BASE = pathlib.Path(__file__).resolve().parents[1]

def risk_from(scenario, quality, consent):
    if consent != 'active': return 'A4'
    if quality < 0.60: return 'A0'
    if 'Exoskeleton' in scenario: return 'A3'
    if 'EMG' in scenario: return 'A2' if quality > 0.75 else 'A1'
    return 'A1'

def build_packet(case):
    risk = risk_from(case['scenario'], case['quality'], case['consent'])
    residuals = []
    if case['quality'] < 0.70: residuals.append('low signal quality')
    if case['consent'] != 'active': residuals.append('consent not active')
    if risk == 'A3': residuals.append('physical action requires human approval and external safety controller')
    return {
        'packet_id': f"PKT-{case['case_id']}",
        'session_id': 'SES-DEMO',
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'D_data_layer': [f"scenario={case['scenario']}", f"quality={case['quality']}"],
        'I_information_layer': ['interpretable candidate event' if case['quality'] >= .7 else 'low-confidence event only'],
        'K_knowledge_layer': ['non-invasive MVP rules', 'DIKWP packet construction policy'],
        'W_wisdom_layer': {'risk_grade': risk, 'review_required': risk in ['A3','A4']},
        'P_purpose_layer': {'consent_state': case['consent'], 'forbidden': ['diagnosis','treatment','advertising','unapproved physical control']},
        'intent_hypotheses': [{'label':'semantic_interaction_candidate','confidence': max(0, min(.95, case['quality']-.05))}],
        'risk_grade': risk,
        'residuals': residuals,
        'kill_conditions': ['consent withdrawn', 'quality<0.60', 'purpose mismatch', 'action grade exceeds adapter permission']
    }

def main():
    cases = json.loads((BASE/'data/sample_route_cases.json').read_text(encoding='utf-8'))
    events=[]
    for c in cases:
        pkt=build_packet(c)
        events.append({'event':'packet_generated','case_id':c['case_id'],'packet':pkt})
    bundle={'platform':'DIKWP NeuroBody SemanticOS','session_id':'SES-DEMO','events':events,'exported_at':time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    out=BASE/'data/sample_session_log.json'
    out.write_text(json.dumps(bundle,ensure_ascii=False,indent=2),encoding='utf-8')
    print('wrote', out)

if __name__ == '__main__': main()
